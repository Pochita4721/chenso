<script>

<h1> Dreams Gaming </h1>

<button type="button"
onclick="document.getElementById('demo').innerHTML = Date()">
click me to add to car. </button>

<p id="demo"></p>



</script>